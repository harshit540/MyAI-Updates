import os, sys, json, zipfile, shutil, subprocess, urllib.request
import tkinter as tk
from tkinter import messagebox

# ============================================================
#  GitHub URLs — harshit540/MyAI-Updates
# ============================================================
VERSION_URL  = "https://raw.githubusercontent.com/harshit540/MyAI-Updates/main/version.json"
# ============================================================

APP_DIR  = os.path.dirname(os.path.abspath(__file__))
VER_FILE = os.path.join(APP_DIR, "version.txt")
ZIP_PATH = os.path.join(APP_DIR, "_update.zip")
TEMP_DIR = os.path.join(APP_DIR, "_temp")


def _status(label, text, color="#f9e2af"):
    if label:
        label.after(0, lambda: label.config(text=text, fg=color))


def read_local_version():
    try:
        with open(VER_FILE, encoding="utf-8") as f:
            return f.read().strip()
    except:
        return "0.0"


def fetch_version_info(status_label):
    _status(status_label, "Checking for update...")
    try:
        req = urllib.request.Request(VERSION_URL)
        with urllib.request.urlopen(req, timeout=10) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.URLError as e:
        _status(status_label, f"Cannot reach server.", "#f38ba8")
        return None
    except Exception as e:
        _status(status_label, f"Error: {str(e)[:40]}", "#f38ba8")
        return None


def download_zip(url, status_label):
    _status(status_label, "Downloading update...")
    try:
        urllib.request.urlretrieve(url, ZIP_PATH)
        _status(status_label, "Download complete!")
        return True
    except Exception as e:
        _status(status_label, f"Download failed.", "#f38ba8")
        return False


def extract_and_replace(status_label):
    _status(status_label, "Installing update...")
    if os.path.exists(TEMP_DIR):
        shutil.rmtree(TEMP_DIR)
    os.makedirs(TEMP_DIR)

    with zipfile.ZipFile(ZIP_PATH, 'r') as z:
        z.extractall(TEMP_DIR)

    for item in os.listdir(TEMP_DIR):
        if item == "data":
            continue  # user data safe!
        src = os.path.join(TEMP_DIR, item)
        dst = os.path.join(APP_DIR, item)
        if os.path.isfile(src):
            shutil.copy2(src, dst)
        elif os.path.isdir(src):
            if os.path.exists(dst):
                shutil.rmtree(dst)
            shutil.copytree(src, dst)

    shutil.rmtree(TEMP_DIR, ignore_errors=True)
    if os.path.exists(ZIP_PATH):
        os.remove(ZIP_PATH)


def _do_restart(root):
    root.destroy()
    subprocess.Popen([sys.executable, os.path.join(APP_DIR, "app.py")])
    sys.exit(0)


def run_updater(status_label=None, root=None):
    local_ver = read_local_version()

    info = fetch_version_info(status_label)
    if info is None:
        return False

    online_ver = info.get("version", "0.0")

    if online_ver == local_ver:
        _status(status_label, "Already latest version!", "#a6e3a1")
        return False

    # Update available!
    changelog = info.get("changelog", "Bug fixes and improvements")
    download_url = info.get("download_url", "")

    answer = messagebox.askyesno(
        "Update Available!",
        f"New version found!\n\n"
        f"  Current : v{local_ver}\n"
        f"  New     : v{online_ver}\n\n"
        f"What's new:\n{changelog}\n\n"
        f"Install now?"
    )
    if not answer:
        _status(status_label, "Update skipped.", "#6c7086")
        return False

    if not download_zip(download_url, status_label):
        return False

    extract_and_replace(status_label)
    _status(status_label, "Done! Restarting...", "#a6e3a1")

    if root:
        root.after(1200, lambda: _do_restart(root))
    return True
