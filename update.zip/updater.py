# ============================================================
#  updater.py — Auto Update System
#
#  GitHub પર 2 files રાખો:
#  1. version.json  — latest version info
#  2. update.zip    — new version files
#
#  SETUP:
#  VERSION_URL ને તમારા GitHub Raw URL થી બદલો
#  (નીચે CONFIG section માં)
# ============================================================

import os
import sys
import json
import zipfile
import shutil
import urllib.request   # requests install ન હોય તો પણ ચાલે
import subprocess
import tkinter as tk
from tkinter import messagebox

# -------------------------------------------------------
# ⚙️  CONFIG — ફક્ત આ URL બદલો
# -------------------------------------------------------
VERSION_URL = "https://raw.githubusercontent.com/YOUR_USERNAME/MyAI-Updates/main/version.json"
# -------------------------------------------------------

APP_DIR   = os.path.dirname(os.path.abspath(__file__))
VER_FILE  = os.path.join(APP_DIR, "version.txt")
TEMP_DIR  = os.path.join(APP_DIR, "_temp_update")
ZIP_PATH  = os.path.join(APP_DIR, "_update.zip")


# ── Helpers ──────────────────────────────────────────────

def _set_status(label, text, color="#f9e2af"):
    """Tkinter label safe update (thread-safe)"""
    if label:
        label.after(0, lambda: label.config(text=text, fg=color))


def read_local_version():
    try:
        with open(VER_FILE) as f:
            return f.read().strip()
    except FileNotFoundError:
        return "0.0"


def fetch_version_info(status_label):
    """GitHub version.json fetch"""
    _set_status(status_label, "🌐 Connecting to server...")
    try:
        with urllib.request.urlopen(VERSION_URL, timeout=10) as r:
            return json.loads(r.read().decode())
    except Exception as e:
        _set_status(status_label, f"❌ Cannot reach server: {e}", "#f38ba8")
        return None


def download_zip(url, status_label):
    """update.zip download"""
    _set_status(status_label, "⬇️  Downloading update...")
    try:
        urllib.request.urlretrieve(url, ZIP_PATH)
        _set_status(status_label, "✅ Download complete!")
        return True
    except Exception as e:
        _set_status(status_label, f"❌ Download failed: {e}", "#f38ba8")
        return False


def extract_and_replace(status_label):
    """
    ZIP extract → files replace
    data/ folder ને NEVER touch કરવાનો
    """
    _set_status(status_label, "📂 Extracting files...")

    # Clean temp
    if os.path.exists(TEMP_DIR):
        shutil.rmtree(TEMP_DIR)
    os.makedirs(TEMP_DIR)

    with zipfile.ZipFile(ZIP_PATH, 'r') as z:
        z.extractall(TEMP_DIR)

    _set_status(status_label, "🔄 Replacing old files...")

    for item in os.listdir(TEMP_DIR):
        if item == "data":
            continue                            # User data safe!
        src = os.path.join(TEMP_DIR, item)
        dst = os.path.join(APP_DIR, item)
        if os.path.isfile(src):
            shutil.copy2(src, dst)
        elif os.path.isdir(src):
            if os.path.exists(dst):
                shutil.rmtree(dst)
            shutil.copytree(src, dst)

    # Cleanup temp files
    shutil.rmtree(TEMP_DIR, ignore_errors=True)
    if os.path.exists(ZIP_PATH):
        os.remove(ZIP_PATH)

    _set_status(status_label, "✅ Files replaced!", "#a6e3a1")


def restart_app(root):
    """App restart"""
    root.after(1500, lambda: _do_restart(root))


def _do_restart(root):
    root.destroy()
    subprocess.Popen([sys.executable, os.path.join(APP_DIR, "app.py")])
    sys.exit(0)


# ── Main Entry ───────────────────────────────────────────

def run_updater(status_label=None, root=None):
    """
    Full update flow.
    Returns True if updated, False if already latest / error.
    """
    local_ver = read_local_version()
    print(f"[Updater] Local: v{local_ver}")

    info = fetch_version_info(status_label)
    if info is None:
        return False

    online_ver = info.get("version", "0.0")
    print(f"[Updater] Online: v{online_ver}")

    if online_ver == local_ver:
        print("[Updater] Already latest!")
        return False

    # ── Update available popup ────────────────────────────
    changelog  = info.get("changelog", "Bug fixes and improvements")
    download_url = info.get("download_url", "")

    answer = messagebox.askyesno(
        "Update Available! 🎉",
        f"New version found!\n\n"
        f"  Current : v{local_ver}\n"
        f"  New     : v{online_ver}\n\n"
        f"What's new:\n{changelog}\n\n"
        f"Install now?"
    )
    if not answer:
        _set_status(status_label, "⏭️ Update skipped.", "#6c7086")
        return False

    # ── Download ─────────────────────────────────────────
    if not download_zip(download_url, status_label):
        return False

    # ── Extract + Replace ────────────────────────────────
    extract_and_replace(status_label)

    # ── Restart ──────────────────────────────────────────
    _set_status(status_label, "🚀 Restarting app...", "#a6e3a1")
    if root:
        restart_app(root)

    return True
