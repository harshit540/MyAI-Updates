# ============================================================
#  MyAI - Version 2.0  ✨ UPDATED!
#
#  NEW Features:
#  - Chat box with scrollable history
#  - Memory — messages save to data/memory.json
#  - Better UI + colors
#  - Enter key to send
# ============================================================

import tkinter as tk
from tkinter import scrolledtext, messagebox
import json
import os
import threading
import updater


MEMORY_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "memory.json")


def load_memory():
    if os.path.exists(MEMORY_FILE):
        with open(MEMORY_FILE, "r") as f:
            return json.load(f)
    return []


def save_memory(history):
    os.makedirs(os.path.dirname(MEMORY_FILE), exist_ok=True)
    with open(MEMORY_FILE, "w") as f:
        json.dump(history, f, indent=2, ensure_ascii=False)


def do_update(root, status_label, update_btn):
    update_btn.config(state="disabled", text="Updating...")
    status_label.config(text="🔄 Checking...", fg="#f9e2af")

    def run():
        result = updater.run_updater(status_label, root)
        if not result:
            update_btn.config(state="normal", text="Check Update")
            status_label.config(text="✅ Already latest!", fg="#a6e3a1")

    threading.Thread(target=run, daemon=True).start()


def run_app():
    history = load_memory()

    root = tk.Tk()
    root.title("MyAI — v2.0  ✨")
    root.geometry("450x520")
    root.resizable(False, False)
    root.configure(bg="#1e1e2e")

    # ---- Header ----
    tk.Label(root, text="🤖 MyAI", bg="#1e1e2e", fg="#cba6f7",
             font=("Arial", 20, "bold")).pack(pady=(15, 2))

    tk.Label(root, text="Version 2.0  ✨ Now with Memory!",
             bg="#1e1e2e", fg="#a6e3a1", font=("Arial", 9)).pack()

    # ---- Chat Box ----
    chat_box = scrolledtext.ScrolledText(
        root, bg="#313244", fg="#cdd6f4",
        font=("Consolas", 10), height=16,
        state="disabled", wrap=tk.WORD,
        relief="flat"
    )
    chat_box.pack(padx=15, pady=12, fill=tk.BOTH, expand=True)

    # Load previous messages
    chat_box.config(state="normal")
    if history:
        chat_box.insert(tk.END, "— Previous messages —\n\n")
        for msg in history[-10:]:
            chat_box.insert(tk.END, msg + "\n")
        chat_box.insert(tk.END, "\n")
    chat_box.config(state="disabled")
    chat_box.see(tk.END)

    # ---- Input Row ----
    input_frame = tk.Frame(root, bg="#1e1e2e")
    input_frame.pack(padx=15, pady=(0, 8), fill=tk.X)

    entry = tk.Entry(input_frame, bg="#45475a", fg="white",
                     font=("Arial", 11), insertbackground="white",
                     relief="flat")
    entry.pack(side=tk.LEFT, expand=True, fill=tk.X, padx=(0, 6), ipady=5)

    def send_message(event=None):
        msg = entry.get().strip()
        if not msg:
            return
        reply = f"MyAI: Got it! You said — '{msg}'"
        history.append(f"You: {msg}")
        history.append(reply)
        save_memory(history)
        chat_box.config(state="normal")
        chat_box.insert(tk.END, f"You: {msg}\n{reply}\n\n")
        chat_box.see(tk.END)
        chat_box.config(state="disabled")
        entry.delete(0, tk.END)

    tk.Button(input_frame, text="Send", command=send_message,
              bg="#cba6f7", fg="#1e1e2e", font=("Arial", 10, "bold"),
              width=7, relief="flat", cursor="hand2").pack(side=tk.RIGHT)
    entry.bind("<Return>", send_message)

    # ---- Status label ----
    status_label = tk.Label(root, text="", bg="#1e1e2e", fg="#a6e3a1",
                            font=("Arial", 8))
    status_label.pack()

    # ---- Bottom Buttons ----
    btn_frame = tk.Frame(root, bg="#1e1e2e")
    btn_frame.pack(pady=8)

    update_btn = tk.Button(btn_frame, text="Check Update",
                           bg="#89b4fa", fg="#1e1e2e",
                           font=("Arial", 10, "bold"), width=16,
                           relief="flat", cursor="hand2")
    update_btn.config(command=lambda: do_update(root, status_label, update_btn))
    update_btn.pack(side=tk.LEFT, padx=5)

    tk.Button(btn_frame, text="Stop / Close", command=root.destroy,
              bg="#e74c3c", fg="white", font=("Arial", 10),
              width=14, relief="flat", cursor="hand2").pack(side=tk.LEFT, padx=5)

    root.mainloop()


if __name__ == "__main__":
    run_app()
